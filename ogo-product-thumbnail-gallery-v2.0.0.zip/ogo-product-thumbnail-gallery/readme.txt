=== OGO Product Thumbnail Gallery ===
Contributors: Alexandr Ogorodnikov
Tags: woocommerce,image,hover,product,slider,animations
Stable tag: 2.0.0
Requires at least: 4.9
Tested up to: 5.8
Requires PHP: 5.6
License: GPLv2 or later
License URI: https://www.gnu.org/licenses/gpl-2.0.html

== Description ==

Displaying a gallery of product images on the category page. Hovering method or swap for mobile devices.